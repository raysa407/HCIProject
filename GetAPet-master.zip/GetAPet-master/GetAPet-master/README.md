# GetAPet

![Alt text](./raw/app_icon.png)

Pet adoption app under active development. Used as a playground for some fancy Material Design theming, animations and
some architecture libraries. It'll also be used as a base for some UI based series of short blogposts.
